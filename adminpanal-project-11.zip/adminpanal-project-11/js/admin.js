let userlogin = JSON.parse(localStorage.getItem('checkuser'));
    if (!userlogin) {
        window.location.href = "login.html";
    }