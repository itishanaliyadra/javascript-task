
let record;
if (localStorage.getItem('user') === null && localStorage.getItem('user') === undefined) {
    record = [];
} else {
    record = JSON.parse(localStorage.getItem('user'))
}
function mt() {
    document.getElementById('name').value = "";
    document.getElementById('email').value = "";
    document.getElementById('phone').value = "";
}


viwe();
function viwe() {
    let tbl = "";
    tbl += `
<tr>
<td>Id</td>
<td>Name</td>
<td>Email</td>
<td>Phone</td>
<td>Action</td>
</tr>
`
    record.forEach(val => {
        tbl += `
    <tr>
    <td>${val.id}</td>
    <td>${val.name}</td>
    <td>${val.email}</td>
    <td>${val.phone}</td>
    <td>
    <button onclick="update(${val.id})">Update</button>
    </td>
    <td>
    <button onclick="delet(${val.id})">Delete</button>
    </td>
    </tr>
    `
    });
    document.getElementById('showtable').innerHTML = tbl;
}
function submitdata() {
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let phone = document.getElementById('phone').value;
    let obj = {
        id: Math.floor(Math.random() * 1000),
        name: name,
        email: email,
        phone: phone,
    }
    record.push(obj);
    localStorage.setItem('user', JSON.stringify(record));
    viwe();
    alert("Record is add");
    mt();
}
function delet(id) {
    for (let i in record) {
        if (record[i].id == id) {
            record.splice(i, 1)
        }
        localStorage.setItem('user', JSON.stringify(record));
    }
    alert("Record is delete !");
    viwe();
} function update(id) {
    for (let i=0; i<record.length; i++) {
        if (record[i].id == id) {
            document.getElementById('name').value = record[i].name;
            document.getElementById('email').value = record[i].email;
            document.getElementById('phone').value = record[i].phone;
            document.getElementById('submit').setAttribute('onclick', `updatesubnmit(${record[i].id})`)
        }
    }
}
function updatesubnmit(id){
    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let phone = document.getElementById('phone').value;
    for(let i in record){
        if (record[i].id == id){
           record[i].name=name;
            record[i].email=email;
            record[i].phone=phone;
        }
        localStorage.setItem('user', JSON.stringify(record));
    }
    document.getElementById('submit').setAttribute('onclick', `submitdata()`)
    mt();
    viwe();
}
